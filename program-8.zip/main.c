/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#define MAX 100
int main()
{
    int n, head, i;
    int request[MAX];
    printf("Enter the number of tracks: ");
    scanf("%d", &n);
    printf("Enter the track requests: ");
    for (i = 0; i < n; i++)
        scanf("%d", &request[i]);
    printf("Enter the initial head position: ");
    scanf("%d", &head);
    int move = 0;
    for (i = 0; i < n; i++) {
        move += abs(request[i] - head);
        head = request[i];
    }
    printf("Average head movement: %.2f\n", (float)move / n);
    return 0;
}
