/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define N 3	
int main()
{
    int i, j, k;
    int max[N][N] = {
        {3, 6, 8},
        {4, 3, 3},
        {3, 4, 4}
    };
    int alloc[N][N] = {
        {3, 3, 3},
        {2, 0, 3},
        {1, 2, 4}
    };
    int avail[N] = {1, 2, 0};
    int need[N][N];
    for (i = 0; i < N; i++)
        for (j = 0; j < N; j++)
            need[i][j] = max[i][j] - alloc[i][j];
    int finish[N] = {0};
    int work[N];
    int safe[N];
    int safe_count = 0;
    for (i = 0; i < N; i++)
        work[i] = avail[i];
    for (k = 0; k < N; k++) {
        for (i = 0; i < N; i++) {
            if (finish[i] == 0) {
                int can_run = 1;
                for (j = 0; j < N; j++)
                    if (need[i][j] > work[j])
                        can_run = 0;
                if (can_run) {
                    for (j = 0; j < N; j++)
                        work[j] += alloc[i][j];
                    finish[i] = 1;
                    safe[safe_count++] = i;
                }
            }
        }
    }
    int deadlock = 1;
    for (i = 0; i < N; i++)
        if (finish[i] == 0)
            deadlock = 0;
    if (deadlock) {
        printf("The system is in a deadlock state\n");
        printf("Deadlocked processes:");
        for (i = 0; i < N; i++)
            if (finish[i] == 0)
                printf(" %d", i);
        printf("\n");
    } else {
        printf("The system is not in a deadlock state\n");
        printf("Safe sequence:");
        for (i = 0; i < safe_count; i++)
            printf(" %d", safe[i]);
        printf("\n");
    }
    return 0;
}
